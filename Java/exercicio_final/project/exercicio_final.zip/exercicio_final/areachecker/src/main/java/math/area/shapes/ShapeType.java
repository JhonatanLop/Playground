package math.area.shapes;

public enum ShapeType {
    SQUARE,
    RECTANGLE,
    CIRCLE,
    TRIANGLE,
    PARALLELOGRAM,
    TRAPEZE,
    HEXAGON,
    RHOMBUS,
    CUBE
}
